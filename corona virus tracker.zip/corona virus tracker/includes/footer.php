<html>
<footer>
<center>
  <div style ="height:100px; width:80%; background:lightblue;">
  </div>
</center>
</footer>
</html>