create a database "covid"
Import the covid.sql file into it

For admin section;
Username = admin
password = admin